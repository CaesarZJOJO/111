# SEG2105Group25

Deliverable 1:

our project known bugs:
sign up new user successful but account don't need to be verified to get in welcome page;

finished tasks:
login as admin   (admin username: admin     admin password admin123)
create instructor account 
create gym member account
see welcome page
admin can create a type class enter nam and description
admin delete class by clicking the list on manage page
admin can delete all members by click the button on manage page

Deliverable 2:

our project known bugs:
none

finished tasks:
1 instrustor modify （level of diffcult(class) +time modify) 
2. instuctro modify(cancel class+ capacity limit + view all calss(database)
3. search bar+ validation for all fields.